# codebuild-for-lambda
This Repository contains the codes for CodeBuild project.
